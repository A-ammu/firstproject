from django.apps import AppConfig


class ScsConfig(AppConfig):
    name = 'scs'
